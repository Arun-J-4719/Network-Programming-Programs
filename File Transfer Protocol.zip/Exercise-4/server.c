#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#define PORT 9227
int main(int argc, char** argv) {
    int sfd,bfd, lfd, connected, size, fdsrc, has_access, msglen, n;
    struct sockaddr_in serv_addr, client_addr;
    char msg[100], destmsg[100];

printf("\n\n*----------------------*\nFTP PROGRAM\n*----------------------*\n\n");

sfd = socket(AF_INET, SOCK_STREAM, 0);

  if(sfd == -1)
	
	perror("SOCKET CREATION FAILED");	

  else

	perror("SOCKET CREATION SUCCESSFULL");

serv_addr.sin_family = AF_INET;
serv_addr.sin_port   = htons(PORT);
serv_addr.sin_addr.s_addr = INADDR_ANY;//inet_addr("172.16.25.155");


bfd = bind(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));

  if(bfd == -1)
  {
	perror("BOUND FAILED");
	exit(1);		
  }
  else

  	perror("BOUND SUCCESSFULL");


lfd = listen(sfd, 5);

  if(lfd == -1)
  {
  	perror("LISTEN FAILED");
	exit(1);
  }
  else
  {
	perror("LISTEN SUCCESSFULLY");
  }
 
 size = sizeof(client_addr);
    connected = accept(sfd, (struct sock_addr *)&client_addr, &size);

   printf("\n Connection from %d", connected);
    
    strcpy(msg,"\nEnter the File Name: ");
    
    send(connected, msg, sizeof(msg), 0);
    //write(cconn, msg, sizeof(msg));
    printf("\n*----------------------*\nMessage Sended\n*----------------------*\n");
   // send(cconn, msg, sizeof(msg), 0);
   recv(connected, destmsg, sizeof(destmsg), 0);
    printf("\n*----------------------*\nMessage Received: %s", destmsg);
    printf("\n\n");

has_access = access(destmsg, F_OK);
            if(has_access!=0){
                strcpy(msg,"\n File Not Exist");
		send(connected, msg, sizeof(msg),0); 
		close(sfd);	
	    close(connected);
	    exit(-1);
}
        
if((has_access = access(destmsg, R_OK))!=0)
	{
        strcpy(msg,"\n File Exist.  But it is not accessible.");
		send(connected, msg, sizeof(msg),0); 
		close(sfd);
	    close(connected); 
		exit(-2);		
	}

 fdsrc = open(destmsg, O_RDONLY);
        strcpy(msg,"\nDownloading File...");
		send(connected, msg, sizeof(msg),0);
        
        while((n = read(fdsrc, msg,sizeof(msg))))
	{
		if(send(connected, msg, n,0) != n)
		{
                    printf(" * Write Error!");
                    close(sfd);
		    close(connected);
		}
		if(n < 0)
		{
			printf(" * Read Error!");
            close(sfd);
			close(connected);
		}
	}

close(sfd);
close(connected);
}








    




