#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include <sys/socket.h>
#include <sys/types.h>

#include <netinet/in.h>
#define PORT 9227

int main(){
    
    int cfd, conn, fd, n,cres;
    struct sockaddr_in serv_addr;
    char msg[100], destmsg[100], fn[40];
   
   
    cfd = socket(AF_INET, SOCK_STREAM, 0);
    printf("\n*----------------------*\nSocket Create successfully\n*----------------------*");
    
    if(cfd < 0)
        return -1;
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htons(INADDR_ANY);
    serv_addr.sin_port = htons(PORT);
    
    printf("\n*----------------------*\nConnection Requested from Server...\n*----------------------*\n");
    conn = connect(cfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
    if(conn == -1){
        printf("\nConnection Refused by Server...");
        exit(-1);
    }
    printf("\n*----------------------*\nConnection Accepted by Server...\n*----------------------*");
    
    recv(cfd, destmsg, sizeof(destmsg),0);
    printf("%s", destmsg);
    scanf("%s", msg);
    printf("\n*----------------------*\nEnter the Destination File Name: ");
    scanf("%s", fn);
    fd = open(fn, O_CREAT|O_WRONLY, 777);	
    send(cfd, msg, sizeof(msg),0);
    recv(cfd, destmsg, sizeof(destmsg),0);
    if(strcmp(destmsg,"Downloading File...") == 0){
        printf("%s\n", destmsg);
        n = recv(cfd, destmsg, sizeof(destmsg),0);
        while(n > 0){
            if(*destmsg != 0){                
                    write(fd, destmsg, n);
                    //clear(destmsg, sizeof(destmsg));                
            }            
            n = recv(cfd, destmsg, sizeof(destmsg),0);
            
        }  
        close(fd);
        printf("%s\n", destmsg);        
    }
    printf("\n*----------------------*\nDownload Completed\n*----------------------*\n");
    close(cfd);
    
    return 0;
}



