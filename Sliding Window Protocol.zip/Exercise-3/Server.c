
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#define PORT 9216

struct frame{
    int seq_no;
    char data;
};

struct ack{
    int seq_no;
    int ack_data;
};
int main(int argc, char** argv) {

    int sconn, cconn, clisize, msglen, tot_pack, tot_frames, tot_neg_ack;
    int win_size; int quit_flag = 1;
    int out_i, in_i, ack_i, snd_index;
    struct sockaddr_in saddr, caddr;
    char msg[100], rmsg[100];
    int l1, l2;    
    
    sconn = socket(AF_INET, SOCK_STREAM, 0);
    
    saddr.sin_addr.s_addr = htons(INADDR_ANY);
    saddr.sin_port = htons(PORT);
    saddr.sin_family = AF_INET;
        
    bind(sconn, (struct sockaddr *) &saddr, sizeof(saddr));
    
    listen(sconn, 5);
    
    clisize = sizeof(caddr);
    cconn = accept(sconn, (struct sock_addr *)&caddr, &clisize);
    printf("\n Connection from %d", cconn);
    
    strcpy(msg,"\nEnter the Window Size: ");
    
    send(cconn, msg, sizeof(msg), 0);
    printf("\n Waiting for Window Size........");
   
    recv(cconn, (int *)&win_size, sizeof(win_size), 0);
    printf("\n Received Window Size: %d", win_size);
    
    //Handling Invalid Window Size
    if(win_size < 1 || win_size > 100){
        strcpy(msg,"Invalid Window Size from Client.  Window Size should be > 0!");
        printf("%s", msg);
        quit_flag = -1;
        send(cconn, &quit_flag, sizeof(quit_flag), 0);        
        //close(sconn); close(cconn);
    }
    else{        
        send(cconn, &quit_flag, sizeof(quit_flag), 0);
        strcpy(msg, "Hello");
        tot_frames = strlen(msg);    
    
        //Update Total Packet Size
        tot_pack = tot_frames / win_size;
        if(tot_frames % win_size != 0)
        tot_pack++;
    
        printf("\n Sending Total No of Frames(Whole Message Length) [%d]........", tot_frames);
        send(cconn, &tot_frames, sizeof(tot_frames), 0);
        printf("\n Sending Total No of Packets (or) Windows [%d]........", tot_pack);
        send(cconn, &tot_pack, sizeof(tot_pack), 0);
        printf("\n Sending No of Bytes on each Window [%d]........", win_size);
        send(cconn, &win_size, sizeof(win_size), 0);
               
    
        struct frame sf[100];
        struct ack sack[100];
        
        snd_index = 0;
        for(out_i = 0; out_i < tot_pack; out_i++){
            //clearing buffer
            bzero(sf, sizeof(sf));
            //sending data
            structcpy(sf, msg, snd_index, win_size);        
            send(cconn, sf, sizeof(sf), 0);
            //waiting for ack
            l1:
            //tot_neg_ack = recvack(cconn, sack, win_size);
            recv(cconn, (int *)&tot_neg_ack, sizeof(tot_neg_ack), 0);
        recv(cconn, sack, sizeof(sack), 0);
            if(tot_neg_ack == 0){
                goto l2;
            }
            
            int ack_wait = 0, ack_flag = 1;
            for(ack_wait = 0; ack_wait < win_size; ack_wait++){
               if(sack[ack_wait].ack_data == -1) {
                   ack_flag = -1;
                   structcpy(sf, msg, ack_wait, 1);
                   send(cconn, sf, sizeof(struct frame), 0);
               }
            }
            if(ack_flag == -1)
                goto l1;
            l2:
                tot_neg_ack = 0;
            snd_index+=win_size;               
        }
        
        close(sconn); close(cconn);
    }
    return (EXIT_SUCCESS);
}

void structcpy(struct frame *sf, char *ch, int start_index, int n){
    int i;
    for(i = 0; i < n; i++){
        if(*(ch + start_index + i) == 0)
            return;
        sf[i].seq_no = start_index + i;
        sf[i].data = *(ch + start_index + i);
    }
}

int recvack(int cdest,struct ack *sack, int n){
        int tot = 0;
        recv(cdest, (int *)&tot, sizeof(tot), 0);
        recv(cdest, sack, sizeof(sack), 0);
        return tot;    
}
