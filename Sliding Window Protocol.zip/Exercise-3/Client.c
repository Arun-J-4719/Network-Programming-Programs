#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#define PORT 9216

struct frame{
    int seq_no;
    char data;
};

struct ack{
    int seq_no;
    int ack_data;
};

int main(int argc, char** argv) {

    int conn, conn_status, fd, n,cres;
    int win_size,  tot_pack, tot_frames, tot_neg_ack, l1, l2, cnt=0, flg=1;
    int recv_index;
    int out_i, in_i; int quit_flag;
    struct sockaddr_in serv_addr;
    char msg[100], rmsg[100], fn[40];
    
    printf("\nSocket Creating..........");    
    conn = socket(AF_INET, SOCK_STREAM, 0);
    printf("\n Socket Created........");
    
    if(conn < 0)
        return -1;
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(argv[1]);
    serv_addr.sin_port = htons(PORT);
    
    printf("\nConnection Requested from Server.........");
    conn_status = connect(conn, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
    if(conn_status == -1){
        printf("\nConnection Refused by Server.........");
        exit(-1);
    }
    printf("\nConnection Accepted by Server.........");
    
    recv(conn, rmsg, sizeof(rmsg),0);
    printf("%s", rmsg);
    scanf("%d", &win_size);    	
    send(conn, &win_size, sizeof(win_size), 0);
    printf("\n Validating Window Size.........");
    recv(conn, (int *)&quit_flag, sizeof(quit_flag), 0);
    if(quit_flag == -1)
    {
        close(conn); return -1;
    }
    
    
    printf("\n Receiving Total No of Frames.........");
    recv(conn, (int *)&tot_frames, sizeof(tot_frames), 0);
    printf("%d", tot_frames);
    printf("\n Receiving Total No of Packets.........");    
    recv(conn, (int *)&tot_pack, sizeof(tot_pack), 0);
    printf("%d", tot_pack);
    printf("\n Receiving Total No of Bytes on Each Packet.........");
    recv(conn, (int *)&win_size, sizeof(win_size), 0);
    printf("%d\n\n", win_size);
    
    struct frame sf[100];
    struct ack sack[100];        
    int i;
        
    for(out_i = 0, recv_index = 0; out_i < tot_pack; out_i++){    
        //Clearing Buffer
        bzero(sf, sizeof(sf));
        tot_neg_ack = 0;
        
        //Receiving Data of Window Size
        recv(conn, (struct frame *)sf, sizeof(sf), 0);       
        
        //Printing Data
        printf("\n\nData From Server:\n");
        for(i = 0; i < win_size; i++){
            printf("%d %c\n", sf[i].seq_no, sf[i].data);
        }
        
        l1:
        //Getting ACK
	if(flg == 1)
	        ack(sack, recv_index, win_size, &tot_neg_ack);
	else if(flg == -1)
	        ack(sack, recv_index, cnt, &tot_neg_ack);
        printf("\n Total Negative ACK given by you are %d", tot_neg_ack);
        
        //Sending ACK
        printf("\n Sending ACK.....");
        send(conn, &tot_neg_ack, sizeof(tot_neg_ack), 0);
        send(conn, sack, sizeof(sack), 0);
        
        //Checking for negative ack
        if(tot_neg_ack == 0)
            goto l2;
        
        //Receiving Missed Data
        int ack_index = 0, scan_index = 0, flag_negack = 1; cnt = 0; flg = 1;
        for(ack_index = 0; ack_index < tot_neg_ack; ack_index++){
            for(scan_index = recv_index; scan_index < win_size; scan_index++){
                if(sack[scan_index].ack_data == -1){
                    flag_negack = -1; cnt++;
                    recv(conn, (struct frame *)sf, sizeof(struct frame), 0);
                    //printf("\nData Re send:");
                    printf("\n\n %d %c", sf[scan_index].seq_no, sf[scan_index].data); 
                    break;
                }
            }
        }
        if(flag_negack == -1)
            goto l1;
        
        l2:
        //Updating Receive Index
        recv_index+=win_size;
        printf("\n");
    }
    
    close(conn);
    return (EXIT_SUCCESS);
}

void ack(struct ack *acknow, int src_index, int wsize, int *tot_neg_ack){
    int i; *tot_neg_ack = 0;
    printf("\nEnter Ack....\n\n");
    for(i = 0; i < wsize; i++){
          printf("Enter Ack for Frame %d: ", src_index);
          acknow[src_index].seq_no = src_index;
          scanf("%d", &acknow[src_index].ack_data);
          if(acknow[src_index].ack_data == -1){
              *tot_neg_ack += 1;
          }
          src_index++;
    }    
}
