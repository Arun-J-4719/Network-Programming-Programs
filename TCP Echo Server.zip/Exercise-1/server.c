#include<stdio.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>

#define MAXPEND 5

int main()
{
int sfd,bfd,ifd,connected,recv_bytes,length;
int size;
struct sockaddr_in serv_addr,client_addr;
char recv_byte[200];

sfd=socket(AF_INET,SOCK_STREAM,0);

if(sfd==-1)
{
perror("Socket Creation Failed");
}
else
{
perror("Socket Creation Successful");
}

serv_addr.sin_family=AF_INET;
serv_addr.sin_port=htons(6820);
serv_addr.sin_addr.s_addr=INADDR_ANY;
bfd=bind(sfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr));

if(bfd==-1)
{
perror("Bound Failed");
exit(1);
}
else
{
perror("Bound Successful");
}

ifd=listen(sfd,MAXPEND);

if(ifd==-1)
{
perror("Listen Failed");
exit(1);
}
else
{
perror("Listen Success");
}

size=sizeof(client_addr);
connected=accept(sfd,(struct sockaddr*)&client_addr,&size);

if(connected==-1)
{
perror("Accept Failed");
exit(1);
}

recv_bytes=recv(connected,recv_byte,length,0);
recv_byte[recv_bytes]='\0';

while(strcmp(recv_byte,"Quit")!=0)
{
printf("\n Received Message is:%s",recv_byte);
send(connected,"SERVER:DATA RECEIVED SUCCESSFUL",40,0);
recv_bytes=recv(connected,recv_byte,length,0);
recv_byte[recv_bytes]='\0';
}

send(connected,"SERVER:EOC",20,0);
close(sfd);
return 0;
}
