#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<stdlib.h>

int main(int argc,char *argv[])
{
int cfd,connection,recv_bytes,length;
int flag=1;
struct sockaddr_in server_addr;
char msg[200],recv_byte[200];

if(argc!=2)
{
printf("\n Please Enter Server Ip Address\n");
exit(1);
}

printf("\tTCP ECHO SERVER PROGRAM:\n");
printf("\t--- ---- ------ --------\n");

cfd=socket(AF_INET,SOCK_STREAM,0);
if(cfd==-1)
{
perror("\n Can't Open Socket");
exit(1);
}

server_addr.sin_family=AF_INET;
server_addr.sin_port=htons(6000);
server_addr.sin_addr.s_addr=inet_addr(argv[1]);
connection=connect(cfd,(struct sockaddr*)&server_addr,sizeof(server_addr));

if(connection==-1)
{
perror("Connection Failed");
exit(1);
}

while(flag==1)
{
printf("\n Enter the Data:");
scanf("%s",msg);
send(cfd,msg,strlen(msg),0);
recv_bytes=recv(cfd,recv_byte,length,0);
recv_byte[recv_bytes]='\0';
printf("%s",recv_byte);
}
		
if(strcmp(recv_byte,"SERVER:EOC")==0)
{
flag=0;
}

printf("\n");
close(cfd);
return 0;
}
